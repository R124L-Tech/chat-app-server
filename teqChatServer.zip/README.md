# Deployment config

## /config/Database.php

`change database credential`

## /api/User/upload_profile.php

`change $server_uri`
